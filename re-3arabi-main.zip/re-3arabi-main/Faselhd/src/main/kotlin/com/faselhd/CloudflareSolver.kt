package com.faselhd

import android.R
import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.MotionEvent
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

object CloudflareSolver {
    private const val TAG = "CF_Solver_Hidden"

    suspend fun solve(activity: Activity?, url: String, userAgent: String): Document? {
        return suspendCoroutine { continuation ->
            if (activity == null || activity.isFinishing) {
                continuation.resume(null)
                return@suspendCoroutine
            }

            Log.d(TAG, "🚀 [بدء السولفر] فتح الرابط الأولي: $url")

            Handler(Looper.getMainLooper()).post {
                val rootView = activity.findViewById<ViewGroup>(R.id.content) ?: run {
                    continuation.resume(null)
                    return@post
                }

                val webView = WebView(activity)
                webView.layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                webView.alpha = 0f
                webView.translationX = 10000f
                webView.isFocusable = false
                webView.isFocusableInTouchMode = false
                webView.isClickable = false

                webView.settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    this.userAgentString = userAgent
                    useWideViewPort = true
                    loadWithOverviewMode = true
                }

                val cookieManager = CookieManager.getInstance()
                cookieManager.setAcceptCookie(true)
                cookieManager.setAcceptThirdPartyCookies(webView, true)

                var isSolved = false
                var isProcessingClick = false
                val pollingHandler = Handler(Looper.getMainLooper())

                fun finishSuccess(html: String?, finalResolvedUrl: String) {
                    if (!isSolved) {
                        isSolved = true
                        cookieManager.flush()

                        Log.d(TAG, "==================================================")
                        Log.d(TAG, "🎯 [نجاح] الرابط النهائي المستقر بعد التحويلات:")
                        Log.d(TAG, "📍 Final URL: $finalResolvedUrl")
                        Log.d(TAG, "🍪 Cookies: ${cookieManager.getCookie(finalResolvedUrl)}")
                        Log.d(TAG, "==================================================")
                        try {
                            val parsedUri = android.net.Uri.parse(finalResolvedUrl)
                            val host = parsedUri.host
                            if (!host.isNullOrBlank() && host.contains("faselhdx")) {
                                val detectedBase = "${parsedUri.scheme ?: "https"}://$host"
                                FASELHD.savePermanentBaseUrl(detectedBase)
                                Log.d(TAG, "💾 [تم الحفظ الدائم]: $detectedBase")
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "خطأ في حفظ الدومين الدائم: ${e.message}")
                        }

                        try {
                            pollingHandler.removeCallbacksAndMessages(null)
                            rootView.removeView(webView)
                            webView.destroy()
                        } catch (e: Exception) {}

                        if (html == null) {
                            Log.w(TAG, "⚠️ فشل جلب محتوى HTML (انتهت المهلة)")
                            continuation.resume(null)
                            return
                        }

                        var cleanHtml = html.removeSurrounding("\"")
                            .replace("\\u003C", "<")
                            .replace("\\u003E", ">")
                            .replace("\\\"", "\"")
                            .replace("\\\\", "\\")

                        continuation.resume(Jsoup.parse(cleanHtml, finalResolvedUrl))
                    }
                }

                pollingHandler.postDelayed({ 
                    val currentFallbackUrl = webView.url ?: url
                    Log.w(TAG, "⏰ انتهت مهلة 60 ثانية. الرابط عند التوقف: $currentFallbackUrl")
                    finishSuccess(null, currentFallbackUrl) 
                }, 60000)

                fun simulateRealTouch(view: WebView, cssX: Float, cssY: Float) {
                    val density = activity.resources.displayMetrics.density
                    val realX = cssX * density
                    val realY = cssY * density
                    val downTime = SystemClock.uptimeMillis()
                    val eventTime = SystemClock.uptimeMillis() + 50
                    val downEvent = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, realX, realY, 0)
                    view.dispatchTouchEvent(downEvent)
                    view.postDelayed({
                        val upEvent = MotionEvent.obtain(downTime, eventTime, MotionEvent.ACTION_UP, realX, realY, 0)
                        view.dispatchTouchEvent(upEvent)
                        downEvent.recycle()
                        upEvent.recycle()
                    }, 50)
                }

                val targetCssPath = "html > body > div:nth-of-type(1) > div > div:nth-of-type(2) > div"

                fun startPolling() {
                    val runnable = object : Runnable {
                        override fun run() {
                            if (isSolved || isProcessingClick) {
                                pollingHandler.postDelayed(this, 2000)
                                return
                            }

                            val jsGetCoords = """
                                (function(){
                                    try{
                                        var box = document.querySelector("$targetCssPath");
                                        if(!box) return "NO_BOX";
                                        var r = box.getBoundingClientRect();
                                        if(r.width === 0 && r.height === 0) return "NO_BOX";
                                        var size = Math.min(36, Math.max(18, Math.round(r.height * 0.55)));
                                        var margin = Math.round(Math.max(8, r.width * 0.03));
                                        var centerY = r.top + (r.height / 2);
                                        var rightSideX = r.right - (size / 2) - margin;
                                        var leftSideX = r.left + (size / 2) + margin;
                                        return rightSideX + "," + centerY + "|" + leftSideX + "," + centerY;
                                    }catch(e){ return "ERROR"; }
                                })();
                            """.trimIndent()

                            webView.evaluateJavascript(jsGetCoords) { res ->
                                try {
                                    val clean = res?.removeSurrounding("\"")
                                    if (clean != null && clean.contains("|")) {
                                        isProcessingClick = true
                                        val sides = clean.split("|")
                                        val (rx, ry) = sides[0].split(",").map { it.toFloatOrNull() }
                                        val (lx, ly) = sides[1].split(",").map { it.toFloatOrNull() }
                                        if (rx != null && ry != null && lx != null && ly != null) {
                                            Log.d(TAG, "👆 محاكاة نقر مربع Cloudflare...")
                                            simulateRealTouch(webView, rx, ry)
                                            pollingHandler.postDelayed({
                                                simulateRealTouch(webView, lx, ly)
                                                pollingHandler.postDelayed({ isProcessingClick = false }, 3000)
                                            }, 250)
                                        } else { isProcessingClick = false }
                                    }
                                } catch (e: Exception) { isProcessingClick = false }
                            }
                            pollingHandler.postDelayed(this, 2000)
                        }
                    }
                    pollingHandler.post(runnable)
                }

                var lastUrl: String? = null
                var stableSince = 0L
                var fetched = false

                fun waitUntilReady() {
                    if (isSolved) return
                    val js = """
                        (function(){
                            try{
                                var hasBox = document.querySelector("$targetCssPath") != null;
                                var html = document.documentElement.innerHTML || "";
                                var stillCloudflare = html.toLowerCase().includes("cloudflare") || html.toLowerCase().includes("checking your browser");
                                return location.href + "|" + document.readyState + "|" + hasBox + "|" + stillCloudflare;
                            }catch(e){ return location.href + "|loading|false|true"; }
                        })();
                    """.trimIndent()

                    webView.evaluateJavascript(js) { res ->
                        if (res == null) {
                            pollingHandler.postDelayed({ waitUntilReady() }, 200)
                            return@evaluateJavascript
                        }

                        val parts = res.replace("\"", "").split("|")
                        if (parts.size < 4) {
                            pollingHandler.postDelayed({ waitUntilReady() }, 200)
                            return@evaluateJavascript
                        }

                        val (currentUrl, ready, hasBox, stillCloudflare) = parts
                        val now = SystemClock.uptimeMillis()

                        if (currentUrl != lastUrl) {
                            Log.d(TAG, "🔄 [تحويل مسار / Redirect]: $lastUrl ➡️ $currentUrl")
                            lastUrl = currentUrl
                            stableSince = now
                        }
                        val stableTime = now - stableSince

                        if (hasBox == "false" && stillCloudflare == "false" && ready == "complete" && stableTime > 1500 && !fetched) {
                            fetched = true
                            Log.d(TAG, "✨ تم فك الحماية وتخطي التحدي بنجاح، جاري استخراج كود الصفحة...")
                            pollingHandler.postDelayed({
                                webView.evaluateJavascript("document.documentElement.outerHTML") { html ->
                                    finishSuccess(html, currentUrl)
                                }
                            }, 500)
                            return@evaluateJavascript
                        }
                        pollingHandler.postDelayed({ waitUntilReady() }, 200)
                    }
                }

                webView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, loadedUrl: String?) {
                        super.onPageFinished(view, loadedUrl)
                        Log.d(TAG, "📄 اكتمل تحميل صفحة: $loadedUrl")
                        isProcessingClick = false
                        startPolling()
                        waitUntilReady()
                    }
                }

                rootView.addView(webView)
                webView.loadUrl(url)
            }
        }
    }
}
