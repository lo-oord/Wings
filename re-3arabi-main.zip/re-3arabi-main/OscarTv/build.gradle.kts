version = 2

cloudstream {
    description = "أفلام ومسلسلات وأنمي وقنوات مباشرة — Oscar TV — سيرفرات مباشرة 360p-1080p"
    authors = listOf("mo7AmMeD64")
    language = "ar"

    status = 0

    tvTypes = listOf(
        "Movie",
        "TvSeries",
        "Anime",
        "TvChannel",
        "Live",
    )
iconUrl = "https://raw.githubusercontent.com/Abodabodd/re-3arabi/refs/heads/main/OscarTv/icon.png"
}
